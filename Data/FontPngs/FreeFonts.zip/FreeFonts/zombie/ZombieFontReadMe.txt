Zombie!

Zombie is based on a typeface called Neuland Black, which I sloppily traced with a Warm Gray Berol Prismacolor marker, then scanned and fontified with an expensive computer for your typesetting pleasure.

Zombie is a free font, and may be copied and distributed to your heart's content, so long as you include this readme file. If you design something really fabulous with it, please drop me a line and let me know, or God will get you when you die. Enjoy!

Patrick Broderick
rotodesign
350 Bay Street, Suite 100-328
San Francisco, CA 94133


pat@rotodesign.com
http://www.rotodesign.com


